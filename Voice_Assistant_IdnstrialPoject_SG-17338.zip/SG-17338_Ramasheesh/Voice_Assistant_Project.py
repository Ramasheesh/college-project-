import pyttsx3
import datetime
import speech_recognition as sr
import wikipedia
import webbrowser
import os
import pyjokes
import tkinter as tk

engine = pyttsx3.init("sapi5")
voices = engine.getProperty("voices")
engine.setProperty('voice', voices[1].id)


def wishMe():
    hour = int(datetime.datetime.now().hour)
    if 0 <= hour < 12:
        speak("Good Morning, Sir!")
    elif 12 <= hour < 18:
        speak("Good Afternoon, Sir!")
    else:
        speak("Good Evening, Sir!")
    speak("Hi! I'm your personal Jarvis")


def speak(audio, voiceRate=200):
    engine.setProperty('rate', voiceRate)
    engine.say(audio)
    engine.runAndWait()


def takeCommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 0.5
        audio = r.listen(source)

    try:
        print("Recognizing....")
        query = r.recognize_google(audio, language="en-in")

    except Exception as e:
        print(e)
        speak("Say that again please...")
        return "None"

    return query


def joke():
    temp_joke = pyjokes.get_joke()
    print(temp_joke)
    speak(temp_joke, 150)


def wikipedia_search(query):
    speak("Searching Wikipedia...")
    query = query.replace("wikipedia", "")
    results = wikipedia.summary(query, sentences=2)
    speak("According to Wikipedia,")
    speak(results)


def open_youtube():
    webbrowser.open("youtube.com")


def send_mail():
    pass


def google_search():
    speak("What do you want to search, Sir?")
    search = takeCommand().lower()
    webbrowser.get("C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s").open(search)


def shut_down():
    os.system("shutdown /s /t 1")


def restart():
    os.system("shutdown /r /t 1")


# class MyWindow(tk.Frame):
#     __width_l = 800
#     __height_l = 600
#
#     def __init__(self, master=None):
#         super().__init__(master)
#         self.master = master
#         self.master.title("Jarvis Voice Assistant")
#         self.master.geometry(str(MyWindow.__width_l)+"x"+str(MyWindow.__height_l))
#         self.master.maxsize(width=MyWindow.__width_l, height=MyWindow.__height_l)
#         self.master.minsize(width=MyWindow.__width_l, height=MyWindow.__height_l)
#         self.master.configure(bg='#2196F3')
#         self.master.iconbitmap("jarvisicon.ico")
#         self.master.bind("<F11>", self.toggleFullScreen)
#         self.master.bind("<Escape>", self.quitFullScreen)
#         self.fullScreenState = False
#         self.create_widgets()
#
#     def toggleFullScreen(self, event):
#         self.fullScreenState = not self.fullScreenState
#         self.master.attributes("-fullscreen", self.fullScreenState)
#
#     def quitFullScreen(self, event):
#         self.fullScreenState = False
#         self.master.attributes("-fullscreen", self.fullScreenState)
#
#     def create_widgets(self):
#         self.heading = tk.Label(self.master, text="JARVIS Voice Assistant", background="#2196F3", foreground="#FFFFFF", justify="center", font="Bahnschrift 28")
#         self.heading.grid(column=2, row=0, columnspan=3, sticky="NSEW", padx=20, pady=20)
#
#
#         self.buttonYoutube = tk.Button(self.master, text="Open YOUTUBE", background="#536DFE", foreground="#FFFFFF", justify="center")
#         self.buttonYoutube.grid(column=1, row=1, columnspan=2, sticky="NSEW", padx=10, pady=10)
#
#         self.buttonGoogle = tk.Button(self.master, text="Open Google", background="#536DFE", foreground="#FFFFFF", justify="center")
#         self.buttonGoogle.grid(column=1, row=2, columnspan=2, sticky="NSEW", padx=10, pady=10)
#
#         self.entryWikipedia = tk.Entry(self.master)
#         self.entryWikipedia.grid(column=0, row=3, sticky="NSEW", padx=10, pady=10)
#         self.buttonWikipedia = tk.Button(self.master, text="Search WIKIPEDIA", background="#536DFE", foreground="#FFFFFF", justify="center")
#         self.buttonWikipedia.grid(column=1, row=3, columnspan=2, sticky="NSEW", padx=10, pady=10)
#
#         self.buttonJoke = tk.Button(self.master, text="Tell a Joke", background="#536DFE", foreground="#FFFFFF", justify="center")
#         self.buttonJoke.grid(column=1, row=4, columnspan=2, sticky="NSEW", padx=10, pady=10)
#
#         self.buttonRestart = tk.Button(self.master, text="RESTART Laptop", background="#536DFE", foreground="#FFFFFF", justify="center")
#         self.buttonRestart.grid(column=1, row=5, columnspan=2, sticky="NSEW", padx=10, pady=10)
#
#         self.buttonShutdown = tk.Button(self.master, text="Shutdown Laptop", background="#536DFE", foreground="#FFFFFF", justify="center")
#         self.buttonShutdown.grid(column=1, row=6, columnspan=2, sticky="NSEW", padx=10, pady=10)
#
#         self.buttonMic = tk.Button(self.master, image=ph)
#         self.buttonMic.grid(column=6, row=8)


if __name__ == "__main__":
    # root = tk.Tk()
    # app = MyWindow(master=root)
    # app.mainloop()
    wishMe()
    running = True
    while running:
        query = takeCommand().lower()
        if 'wikipedia' in query:
            wikipedia_search(query)

        elif 'youtube' in query:
            open_youtube()

        elif 'gmail' in query:
            send_mail()

        elif 'google' in query:
            google_search()

        elif 'time' in query:
            time = datetime.datetime.now().strftime("%H:%M:%S")
            speak("Sir, the time is " + time)

        elif 'shut down' in query:
            shut_down()

        elif 'restart' in query:
            restart()

        elif 'joke' in query:
            joke()

        elif 'end' in query or 'stop' in query or 'offline' in query:
            speak("Going offline, Goodbye Sir.")
            running = False
